from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    ld = LaunchDescription()
    
    remapping_publisher = ("number","my_number")
    
    number_publisher_node = Node(
        package="my_py_pkg",
        executable="num_publisher1",
        name="my_number_publisher",
        remappings=[remapping_publisher
                    ],
        parameters=[
            {"number_to_publish": 55},
            {"publish_frequency": 1.0}
        ]
    )
    
    number_counter_node = Node(
        package="my_py_pkg",
        executable="num_counter1",
        name="my_number_counter",
        remappings=[remapping_publisher,("number_count","my_number_count")]
    )
    
    ld.add_action(number_publisher_node)
    ld.add_action(number_counter_node)
    return ld