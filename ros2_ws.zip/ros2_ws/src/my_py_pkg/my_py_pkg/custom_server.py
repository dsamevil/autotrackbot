#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

from my_robot_interfaces.srv import ComputeRectangleArea

class CustomServerNode(Node): 
    def __init__(self):
        super().__init__("custom_servers")
        self.server= self.create_service(ComputeRectangleArea,"custom_server",self.callback_custom_server)
        self.get_logger().info("custom server has been started")

    def callback_custom_server(self, request, response):
        response.area = request.length * request.width
        self.get_logger().info(str(request.length)+ ' + ' + str(request.width)+ ' = ' + str(response.area))
        return response
        

def main(args=None):
    rclpy.init(args=args)
    node = CustomServerNode() 
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
