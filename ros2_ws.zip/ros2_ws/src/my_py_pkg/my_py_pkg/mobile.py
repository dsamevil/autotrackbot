#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

from example_interfaces.msg import String

class Mobile_Bot(Node): 
    def __init__(self):
        super().__init__("mobile")
        self.count = 0
        self.robot_name="6969"
        self.publisher = self.create_publisher(String,"robot_news",10) 
        self.timer=self.create_timer(0.5, self.publish_news)
        self.get_logger().info("Robot hacking has been started")

    def publish_news(self):
        msg=String()
        self.count+=1
        msg.data="Processing " + str(self.robot_name) + " collecting data - " + str(self.count)
        self.publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = Mobile_Bot()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
