#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.msg import Int64

class Num_Counter_Subscriber(Node):
    def __init__(self):
        super().__init__("num_receiver")
        self.subscription = self.create_subscription(Int64, "number_count", self.callback, 10)
        self.subscription
        self.get_logger().info("num subscriber started")

    def callback(self, msg):
        self.get_logger().info("Received count: %d" % msg.data)

def main(args=None):
    rclpy.init(args=args)
    subscriber_node = Num_Counter_Subscriber()
    rclpy.spin(subscriber_node)
    subscriber_node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
