#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from my_robot_interfaces.msg import LedStateArray
from my_robot_interfaces.srv import SetLed

class LedPannelNode(Node): # MODIFY NAME
    def __init__(self):
        super().__init__("led_pannel") # MODIFY NAME
        self.declare_parameter("led_lights",[0, 0, 0])
        self.led_pannel = self.get_parameter("led_lights").value
        
        self.led_state_publisher = self.create_publisher(LedStateArray, "led_states",10)
        self.led_state_timer = self.create_timer(1, self.publish_led_state)
        
        self.set_led_service = self.create_service(SetLed,"set_led",self.callback_set_led)
        
        self.get_logger().info("led pannel node has been started")
        
        
    def publish_led_state(self):
        msg = LedStateArray()
        msg.led_states = self.led_pannel
        self.led_state_publisher.publish(msg)
        
    def callback_set_led(self, request, response):
        led_number = request.led_number
        state = request.state
        
        if led_number > len(self.led_pannel) or led_number <= 0:
            response.success = False
            return response
        
        if state not in [0, 1]:
            response.success = False
            return response
        
        self.led_pannel[led_number-1] = state
        response.success = True
        self.publish_led_state()
        return response
            
        

def main(args=None):
    rclpy.init(args=args)
    node = LedPannelNode() # MODIFY NAME
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
