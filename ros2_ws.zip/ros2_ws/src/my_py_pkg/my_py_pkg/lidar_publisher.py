import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2


import random

class LiDARPublisher(Node):
    def __init__(self):
        super().__init__('lidar_publisher')
        self.publisher_ = self.create_publisher(PointCloud2, 'lidar_data', 10)
        timer_period = 1.0  # seconds
        self.timer = self.create_timer(timer_period, self.publish_lidar_data)

    def publish_lidar_data(self):
        # Generate some dummy LiDAR data for demonstration purposes
        width = 10
        height = 1
        points = []
        for _ in range(width * height):
            x = random.uniform(-5.0, 5.0)
            y = random.uniform(-5.0, 5.0)
            z = random.uniform(0.0, 2.0)
            intensity = random.uniform(0.0, 1.0)
            points.append([x, y, z, intensity])

        header = point_cloud2.create_cloud_header(frame_id='lidar_frame')
        point_cloud_msg = point_cloud2.create_cloud_xyz32(header, points)
        self.publisher_.publish(point_cloud_msg)
        self.get_logger().info('Publishing LiDAR data')

def main(args=None):
    rclpy.init(args=args)
    lidar_publisher = LiDARPublisher()
    rclpy.spin(lidar_publisher)
    lidar_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
