#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.msg import Int64
from example_interfaces.srv import SetBool


class Num_Counter_Publisher(Node): 
    def __init__(self):
        super().__init__("count_publisher")
        self.number = 0
        self.publisher = self.create_publisher(Int64, "number_count", 10) 
        self.timer = self.create_timer(1.0, self.publish_num)
        self.subscription = self.create_subscription(Int64, "number", self.callback, 10)
        self.reset_counter_service=self.create_service(SetBool,"reset_counter",self.callback_reset_counter)
        self.get_logger().info("count publisher started")

    def publish_num(self):
        msg = Int64()
        msg.data = self.number
        self.number += 1
        self.get_logger().info("Publishing count: %d" % msg.data)
        self.publisher.publish(msg)

    def callback(self, msg):
        self.get_logger().info("Received num: %d" % msg.data)
    
    def callback_reset_counter(self, request , response):
        if request.data:
            self.number=0
            response.success = True
            response.message = "Counter has been reset..."
        else:
            response.success = False
            response.message = "Counter has not been reset..."
        return response
            

def main(args=None):
    rclpy.init(args=args)
    publisher_node = Num_Counter_Publisher()
    rclpy.spin(publisher_node)
    # publisher_node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
