#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.msg import Int64

class Num_Publisher(Node): 
    def __init__(self):
        super().__init__("num_publisher")
        self.declare_parameter("number_to_publish", 2)
        self.declare_parameter("publish_frequency", 1.0)
        
        self.number = self.get_parameter("number_to_publish").value
        self.frequency = self.get_parameter("publish_frequency").value
        self.publisher = self.create_publisher(Int64, "number", 10) 
        self.timer = self.create_timer(1.0 / self.frequency, self.publish_num)
        self.get_logger().info("num publisher started")

    def publish_num(self):
        msg = Int64()
        msg.data = self.number
        self.number += 1
        self.get_logger().info("Publishing num: %d" % msg.data)
        self.publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    publisher_node = Num_Publisher()
    rclpy.spin(publisher_node)
    publisher_node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
