#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from functools import partial

from my_robot_interfaces.srv import ComputeRectangleArea
from example_interfaces.msg import Float64
class CustomCientNode(Node): 
    def __init__(self):
        super().__init__("custom_client") 
        self.c=Float64()
        self.d=Float64()
        self.call_add_two_ints_server(6.0, 7.0)
        c=float(input("enter length : "))
        d=float(input("enter width : "))
        self.call_add_two_ints_server(c, d)
        
    
    def call_add_two_ints_server(self,len,wid):
        client=self.create_client(ComputeRectangleArea,"custom_server")
        while not client.wait_for_service(1.0):
            self.get_logger().warn("waiting for custom server.....")
        
        request = ComputeRectangleArea.Request()
        request.length = len
        request.width = wid
        
        future= client.call_async(request)
        future.add_done_callback(partial(self.callback_call_add_to_ints, lens=len, wids=wid))
    
    def callback_call_add_to_ints(self, future, lens, wids):
        try:
            response = future.result()
            self.get_logger().info('area of rectangle is '+str(lens)+ ' + ' + str(wids)+ ' = ' + str(response.area))
        except Exception as e:
            self.get_logger().error("service failes %r...",(e,))

def main(args=None):
    rclpy.init(args=args)
    node = CustomCientNode() 
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
