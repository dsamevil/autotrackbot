#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from my_robot_interfaces.msg import LedStateArray

class Led_Subscriber(Node):
    def __init__(self):
        super().__init__("num_receiver")
        self.subscription = self.create_subscription(LedStateArray, "led_states", self.callback, 10)
        self.get_logger().info("led receiver started")

    def callback(self, msg):
        led_states_string = ", ".join(str(x) for x in msg.led_states)
        self.get_logger().info("Battery status: %s" % led_states_string)


def main(args=None):
    rclpy.init(args=args)
    subscriber_node = Led_Subscriber()
    rclpy.spin(subscriber_node)
    subscriber_node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
