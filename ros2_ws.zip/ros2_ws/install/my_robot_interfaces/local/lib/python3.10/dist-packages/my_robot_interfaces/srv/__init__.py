from my_robot_interfaces.srv._catch_turtle import CatchTurtle  # noqa: F401
from my_robot_interfaces.srv._compute_rectangle_area import ComputeRectangleArea  # noqa: F401
from my_robot_interfaces.srv._set_led import SetLed  # noqa: F401
