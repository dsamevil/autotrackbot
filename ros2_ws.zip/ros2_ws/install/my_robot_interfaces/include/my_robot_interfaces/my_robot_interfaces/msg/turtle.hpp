// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACES__MSG__TURTLE_HPP_
#define MY_ROBOT_INTERFACES__MSG__TURTLE_HPP_

#include "my_robot_interfaces/msg/detail/turtle__struct.hpp"
#include "my_robot_interfaces/msg/detail/turtle__builder.hpp"
#include "my_robot_interfaces/msg/detail/turtle__traits.hpp"

#endif  // MY_ROBOT_INTERFACES__MSG__TURTLE_HPP_
