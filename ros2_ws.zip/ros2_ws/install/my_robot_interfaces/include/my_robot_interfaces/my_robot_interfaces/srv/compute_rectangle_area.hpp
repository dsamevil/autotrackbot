// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACES__SRV__COMPUTE_RECTANGLE_AREA_HPP_
#define MY_ROBOT_INTERFACES__SRV__COMPUTE_RECTANGLE_AREA_HPP_

#include "my_robot_interfaces/srv/detail/compute_rectangle_area__struct.hpp"
#include "my_robot_interfaces/srv/detail/compute_rectangle_area__builder.hpp"
#include "my_robot_interfaces/srv/detail/compute_rectangle_area__traits.hpp"

#endif  // MY_ROBOT_INTERFACES__SRV__COMPUTE_RECTANGLE_AREA_HPP_
